import math
import sys


def evaluate(expr: str):
    pass


if __name__ == "__main__":
    expr = sys.argv[1]
    print(evaluate(expr))
