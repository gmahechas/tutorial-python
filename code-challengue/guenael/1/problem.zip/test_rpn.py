import unittest
from rpn import evaluate
from math import sqrt

class TestRpn(unittest.TestCase):
    def test_rpn0(self):
        a = evaluate('5')
        self.assertEqual(a, 5.0)

    def test_rpn1(self):
        a = evaluate('4 5 +')
        self.assertEqual(a, 9.0)
        
    def test_rpn2(self):
        a = evaluate('5 2 /')
        self.assertEqual(a, 2.5)

    def test_rpn3(self):
        a = evaluate('8 2 -')
        self.assertEqual(a, 6.0)

    def test_rpn4(self):
        a = evaluate('4 5 6 * -')
        self.assertEqual(a, -26.0)

    def test_rpn5(self):
        a = evaluate('5 10 sqrt *')
        self.assertEqual(a, sqrt(10) * 5)

    def test_rpn6(self):
        a = evaluate('4 5 * 6 2 * -')
        self.assertEqual(a, 8.0)

    def test_rpn7(self):
        a = evaluate('78 6 * 56 + 5 / 78 6 * 56 sqrt 5 + / - 45 * 7 + sqrt')
        self.assertEqual(a, 55.099438223551964)