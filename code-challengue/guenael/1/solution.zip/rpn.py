import math
import sys

OPS = {
    '+': (2, lambda a, b: b + a),
    '-': (2, lambda a, b: b - a),
    '*': (2, lambda a, b: b * a),
    '/': (2, lambda a, b: b / a),
    'sqrt': (1, lambda a: math.sqrt(a))
}

def evaluate(expr: str):
    def compute(token: str):
        if token in OPS:
            params = [compute(tokens.pop()) for _ in range(OPS[token][0])]
            return OPS[token][1](*params)
        else: 
            return float(token)

    tokens = expr.split(' ')
    return compute(tokens.pop())


if __name__ == "__main__":
    expr = sys.argv[1]
    print(evaluate(expr))
